from django.db import models


# Create your models here.

class empleado(models.Model):
    cedula = models.IntegerField(null=True)
    primer_nombre = models.CharField(max_length=50)
    segundo_nombre = models.CharField(max_length=50)
    primer_apellido = models.CharField(max_length=50)
    segundo_apellido = models.CharField(max_length=50)

    class Meta:
        db_table = "empleado"


class usuario(models.Model):
    nombre_usuario = models.CharField(max_length=50)
    clave = models.CharField(max_length=50)
    cargo = models.CharField(max_length=50, default='empleado')
    empleado_ref = models.ForeignKey(empleado, on_delete=models.CASCADE)

    class Meta:
        db_table = "usuario"


class almacen(models.Model):
    nombre_almacen = models.CharField(max_length=50)

    class Meta:
        db_table = "almacen"


class herramienta(models.Model):
    nombre = models.CharField(max_length=50, unique=True)

    class Meta:
        db_table = "herramienta"


class herramientas_almacen(models.Model):
    herramienta = models.ForeignKey(herramienta, on_delete=models.CASCADE)
    almacen = models.ForeignKey(almacen, on_delete=models.CASCADE)
    cantidad = models.IntegerField(null=True)

    class Meta:
        db_table = "herramientas_en_almacen"


class obra(models.Model):
    ubicacion = models.CharField(max_length=50)
    cantidad = models.IntegerField(null=False)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()
    herramienta = models.ForeignKey(herramienta, on_delete=models.CASCADE)

    class Meta:
        db_table = "obra"


class danado(models.Model):
    cantidad = models.IntegerField()
    herramienta = models.ForeignKey(herramienta, on_delete=models.CASCADE)

    class Meta:
        db_table = "danado"
