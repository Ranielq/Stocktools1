from django.shortcuts import render
from inventario.models import herramienta, almacen, obra, empleado, usuario, danado, herramientas_almacen
from django.db import *


# Create your views here.

# vistas que cargan pantallas

def mostrarInicio(request):
    return render(request, 'iniciar_sesion.html')


def mostrarIndex(request):
    return render(request, 'index.html')


def vista_herramientas(request):
    return render(request, 'registrar_herramientas.html')


def vista_danado(request):
    return render(request, 'registrar_danados.html')


def vista_usuario(request):
    return render(request, 'Registro_usuario.html')


def vista_almacen(request):
    return render(request, 'registrar_almacen.html')


def RegistroHerramienta(request):
    if request.method == 'POST':  # Metodo que se utiliza para obtener los datos de los formularios
        nom = request.POST['txtnom']  # Almacenar el valor recogido en una variable
        cant = request.POST['txtcant']
        pro = herramienta(
            nombre=nom)  # se especifica que a variable "pro" va a ser la que guarde en la tabla de herramienta la variable de su nombre

        try:  # Try utilizado para verificar si la herramienta ya existe, de ser asi no la vuelve a agregar a la bdd
            pro.save()  # Se usa la funcionalidad ".save()" para guardar en la base de datos la informacion que contiene "pro"
        except IntegrityError:
            print('else')

        alm = request.POST['id_almacen']
        if alm == 'Almacen A':  # Se obtiene que almacen estara ubicada la herramienta
            id_alm = 1
        if alm == 'Almacen B':
            id_alm = 2
        id_herr = herramienta.objects.filter(nombre=nom).values(
            'id')  # Es una consulta para obtener el nombre de la herramienta que se acaba de crear
        r_alm = herramientas_almacen(almacen_id=id_alm, herramienta_id=id_herr,
                                     cantidad=cant)  # Se almacena toda la informacion que va a la tabla en una unica variable
        r_alm.save()  # .save() para guardar en la bdd
        datos = {'r': 'Registro Realizado Correctamente!'}
        return render(request, 'registrar_herramientas.html',
                      datos)  # este return seria el final del proceso exitoso de guardado, retornando "r" como parametro para que su html muestre el mensaje de exito
    else:
        datos = {
            'r2': 'No Se Puede Procesar Solicitud.'}  # en caso de que no se realice el proceso correctamente se vera retornado "r2" como parametro para que su html muestre el mensaje de exito
        return render(request, 'registrar_herramientas.html', datos)


def mostrar_herramientas(request):
    pro = herramienta.objects.raw(
        "SELECT a1.id, a1.nombre, sum(b2.cantidad) as cantidad FROM herramienta as a1 inner JOIN herramientas_en_almacen as b2 on a1.id = b2.herramienta_id GROUP by a1.nombre;")
    # La funcion objects.raw() permite ingresar una consulta sql "cruda" para ser enviada y procesada directamente por el servidor sql, se realiza así para consultas mas detalladas
    datos = {'pro': pro}  # Se guardan en un diccionario para ser cargados en el html
    return render(request, 'ver_herramientas.html', datos)


def actualizar_herramientas(request, id):  # para actualizar un valor, se le envia como parametro su id
    try:
        pro = herramienta.objects.get(
            id=id)  # Se usa la funcion para realizar la consulta, pero solo obtiene (get()")  el id de la herramienta a modificar
        datos = {'pro': pro}
        return render(request, 'actualizar_herramienta.html', datos)  # te envia los datos al formulario de actualizar.
    except:
        pro = herramienta.objects.all().values()
        datos = {
            'pro': pro,
            'r2': 'El ID (' + str(id) + ') No Existe. Imposible Actualizar!!'
        }
        return render(request, 'ver_herramientas.html', datos)


def iniciar_sesion(request):
    if request.method == 'POST':
        user = request.POST['usuario']
        pswrd = request.POST['password']
        test = usuario.objects.filter(nombre_usuario=user, clave=pswrd).values('nombre_usuario', 'clave').count()

        if test == 0:
            r = {
                'test': test,
                'r': 'Usuario o contraseña invalidos'
            }
            return render(request, 'iniciar_sesion.html', r)
        else:
            return render(request, 'index.html')


def actualizando_herramienta(request, id):  # Funcion que realiza la actualizacion al obtener la id
    if request.method == 'POST':
        nom = request.POST['txtnom']
        pro = herramienta.objects.get(id=id)
        pro.nombre = nom
        pro.save()
        pro = herramienta.objects.all().values()
        datos = {

            'pro': pro,
            'r': 'actualizacion completada!'
        }
        return render(request, 'ver_herramientas.html', datos)
    else:
        datos = {'r2': 'No Se Puede Procesar Solicitud!!'}
        return render(request, 'actualizar_herramientas.html', datos)


def eliminar_herramienta(request, id):
    try:
        pro = herramienta.objects.get(id=id)
        pro.delete()
        pro = herramienta.objects.all().values()
        datos = {

            'pro': pro,
            'r': 'Registro eliminado.!'
        }
        return render(request, 'ver_herramientas.html', datos)
    except:
        pro = herramienta.objects.all().values()
        datos = {

            'pro': pro,
            'r2': 'Id incorrecto, no se puede eliminar'
        }
        return render(request, 'ver_herramientas.html', datos)


def eliminar_danado(request, id):
    try:
        pro = danado.objects.get(id=id)
        pro.delete()
        pro = danado.objects.all().values()
        datos = {

            'pro': pro,
            'r': 'Registro eliminado.!'
        }
        return render(request, 'ver_danados.html', datos)
    except:
        pro = herramienta.objects.all().values()
        datos = {


            'pro': pro,
            'r2': 'Id incorrecto, no se puede eliminar'
        }
        return render(request, 'ver_danados.html', datos)


def vista_obra(request):
    pro = herramienta.objects.all().values(
        'nombre')  # Se usa el ORM para realizar una consulta de la tabla herramienta, donde se traeran todos los datos (.all()") de la columna nombres (".values(nombre)")
    datos = {'pro': pro}

    return render(request, 'registrar_obra.html', datos)


def vista_herramientas_obras(request):
    pro = obra.objects.all().values()
    datos = {'pro': pro}

    return render(request, 'ver_herramientas_en_obra.html', datos)


def RegistroAlmacen(request):
    if request.method == 'POST':
        nom = request.POST['txtnom']
        pro = almacen(nombre_almacen=nom)
        pro.save()
        datos = {'r': 'Registro Realizado Correctamente!!'}
        return render(request, 'registrar_almacen.html', datos)
    else:
        datos = {'r2': 'No Se Puede Procesar Solicitud!!'}
        return render(request, 'registrar_almacen.html', datos)


def registrar_usuario(request):
    if request.method == 'POST':
        nom1 = request.POST['txtnom']
        nom2 = request.POST['txtnom2']
        ape1 = request.POST['txtape']
        ape2 = request.POST['txtape2']
        cdl = request.POST['txtcdla']
        data = empleado(cedula=cdl, primer_nombre=nom1, segundo_nombre=nom2, primer_apellido=ape1,
                        segundo_apellido=ape2)
    try:
        data.save()
        user = request.POST['txtuser']
        pswrd = request.POST['txtpass']
        cargo = request.POST['txtcargo']
        var = empleado.objects.filter(cedula=cdl).values('id')

        data2 = usuario(nombre_usuario=user, clave=pswrd, cargo=cargo, empleado_ref_id=var)
        data2.save()
        datos = {'r': 'Registro Realizado Correctamente!'}
        return render(request, 'iniciar_sesion.html', datos)
    except:
        datos = {'r2': 'Cedula ya registrada. Intente nuevamente.'}
        return render(request, 'registrar_usuario.html', datos)


def registrar_danados(request):
    if request.method == 'POST':
        cant = request.POST['txtcantidad']
        herr = request.POST['txtherra']
        id_her = herramienta.objects.filter(nombre=herr).values('id')
        data = danado(cantidad=cant, herramienta_id=id_her)

        try:
            data.save()
            datos = {'r': 'Registro Realizado Correctamente!'}
            return render(request, 'registrar_danados.html', datos)
        except:
            datos = {'r2': 'No Se Puede Procesar Solicitud. Verificar nombre de herramienta'}
            return render(request, 'registrar_danados.html', datos)


def actualizando_herram(request, id):
    if request.method == 'POST':
        nom = request.POST['txtnom']
        cant = request.POST['cant']
        pro = herramienta.objects.get(id=id)
        pro.nombre = nom
        pro.cantidad_total = cant
        pro.save()
        pro = herramienta.objects.all().values()
        datos = {

            'pro': pro,
            'r': 'actualizacion completada!'
        }
        return render(request, 'ver_herramientas.html', datos)
    else:
        datos = {'r2': 'No Se Puede Procesar Solicitud!!'}
        return render(request, 'actualizar_herramientas.html', datos)


def registrar_obra(request):
    if request.method == 'POST':
        try:
            ubic = request.POST['txtubi']
            cantidad = request.POST['txtcant']
            f_fin = request.POST['final']
            f_inicio = request.POST['inicio']
            herr = request.POST['txtid_h']
            id_her = herramienta.objects.filter(nombre=herr).values('id')
            data = obra(ubicacion=ubic, cantidad=cantidad, fecha_fin=f_fin, fecha_inicio=f_inicio, herramienta_id=id_her)
            data.save()

            datos = {'r': 'Registro Realizado Correctamente!!'}
            return render(request, 'registrar_obra.html', datos)
        except:
            datos = {'r2': 'No Se Puede Procesar Solicitud. Verificar nombre de herramienta'}
            return render(request, 'registrar_obra.html', datos)


def mostrar_danados(request):
    pro = danado.objects.raw(
        'SELECT b1.id, b1.cantidad, b1.herramienta_id, b2.nombre FROM danado as b1 INNER JOIN herramienta as b2 on b1.herramienta_id = b2.id;')
    datos = {'pro': pro}
    return render(request, 'ver_danados.html', datos)


def mostrar_herramientas_obra(request):
    pro = danado.objects.raw('SELECT * FROM obra as b1 inner join herramienta as b2 on b1.herramienta_id = b2.id;')
    datos = {'pro': pro}

    return render(request, 'ver_herramientas_en_obra.html', datos)


def mostrar_herramientas_almacen(request):
    pro = danado.objects.raw(
        'SELECT * FROM herramienta as a1 INNER JOIN herramientas_en_almacen as a2 on a1.id = a2.herramienta_id inner join almacen as a3 on a2.almacen_id = a3.id')
    datos = {'pro': pro}
    return render(request, 'ver_herramientas_en_almacen.html', datos)


def actualizar_danados(request, id):
    try:
        pro = danado.objects.get(id=id)
        datos = {'pro': pro}
        return render(request, 'actualizar_danados.html', datos)

    except:
        pro = danado.objects.all().values()
        datos = {
            'pro': pro,
            'r2': 'El ID (' + str(id) + ') No Existe. Imposible Actualizar!'
        }
        return render(request, 'ver_danados.html', datos)


def actualizando_danados(request, id):
    if request.method == 'POST':
        id = request.POST['id']
        cant = request.POST['cant']
        pro = danado.objects.get(id=id)
        pro.id = id
        pro.cantidad = cant
        pro.save()
        pro = danado.objects.raw(
            'SELECT b1.id, b1.cantidad, b1.herramienta_id, b2.nombre FROM danado as b1 INNER JOIN herramienta as b2 on b1.herramienta_id = b2.id;')
        datos = {

            'pro': pro,
            'r': 'actualizacion completada!'
        }
        return render(request, 'ver_danados.html', datos)
    else:
        datos = {'r2': 'No Se Puede Procesar Solicitud!!'}
        return render(request, 'actualizar_danados.html', datos)


def mostrar_obra(request):
    pro = obra.objects.all().values()
    datos = {'pro': pro}
    return render(request, 'ver_obra.html', datos)


def actualizar_obra(request, id):
    try:
        pro = obra.objects.get(id=id)
        datos = {'pro': pro}
        return render(request, 'actualizar_obra.html', datos)
    except:
        pro = obra.objects.all().values()
        datos = {
            'pro': pro,
            'r2': 'El ID (' + str(id) + ') No existe. imposible actualizar!'
        }
        return render(request, 'ver_obra.html', datos)


def actualizando_obra(request, id):
    if request.method == 'POST':
        ubic = request.POST['txtubi']
        cant = request.POST['txtcant']
        f_fin = request.POST['final']
        f_inicio = request.POST['inicio']
        herr = request.POST['txtid_h']
        pro = obra.objects.get(id=id)
        pro.ubicacion = ubic
        pro.cantidad = cant
        pro.fecha_inicio = f_inicio
        pro.fecha_fin = f_fin
        pro.herramienta.id = herr
        pro.save()
        pro = obra.objects.all().values()
        datos = {

            'pro': pro,
            'r': 'actualizacion completada!'
        }
        return render(request, 'ver_obra.html', datos)
    else:
        datos = {'r2': 'No Se Puede Procesar Solicitud!!'}
        return render(request, 'ver_obra.html', datos)


def eliminar_obra(request, id):
    try:
        pro = obra.objects.get(id=id)
        pro.delete()
        pro = obra.objects.all().values()
        datos = {

            'pro': pro,
            'r': 'Registro eliminado.!'
        }
        return render(request, 'ver_obra.html', datos)
    except:
        pro = obra.objects.all().values()
        datos = {

            'pro': pro,
            'r2': 'Id incorrecto, no se puede eliminar'
        }
        return render(request, 'ver_obra.html', datos)
