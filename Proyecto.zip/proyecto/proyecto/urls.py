"""proyecto URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from inventario import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.mostrarInicio),
    path('index/', views.mostrarIndex),
    path('vista_herramientas/', views.vista_herramientas),
    path('vista_danados/', views.vista_danado),
    path('vista_almacenes/', views.vista_almacen),
    path('vista_obras/', views.vista_obra),
    path('vista_usuario', views.vista_usuario),
    path('vista_herramientas_obra', views.vista_herramientas_obras),


    path('mostrar_herramientas/', views.mostrar_herramientas),
    path('mostrar_danados/', views.mostrar_danados),
    path('mostrar_obra/', views.mostrar_obra),
    path('mostrar_herramientas_obra/', views.mostrar_herramientas_obra),
    path('mostrar_herramientas_almacen/', views.mostrar_herramientas_almacen),
    path('actualizar_obra/<int:id>', views.actualizar_obra),
    path('actualizando_obra/<int:id>', views.actualizando_obra),
    path('actualizando_danados/<int:id>', views.actualizando_danados),


    path('actualizar_herramienta/<int:id>', views.actualizar_herramientas),
    path('actualizar_danados/<int:id>', views.actualizar_danados),
    path('actualizando_herramienta/<int:id>', views.actualizando_herramienta),
    path('eliminar_herramienta/<int:id>', views.eliminar_herramienta),
    path('eliminar_danado/<int:id>', views.eliminar_danado),
    path('eliminar_obra/<int:id>', views.eliminar_obra),

    path('r_usuario', views.registrar_usuario),
    path('r_danado', views.registrar_danados),
    path('r_herramientas', views.RegistroHerramienta),
    path('r_almacen', views.RegistroAlmacen),
    path('r_obra', views.registrar_obra),
    path('iniciar_sesion', views.iniciar_sesion),

]
